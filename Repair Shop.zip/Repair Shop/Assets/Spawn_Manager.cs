﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawn_Manager : MonoBehaviour
    
{
    
    public Transform[] SpawnPoints;

    public GameObject[] Items;

    int spawnIndex = 0;

    private void Start()
    {
        spawnItems();
        spawnItems();
        spawnItems();
        spawnItems();
        spawnItems();
    }

    private void Update()
    {
        
    }

    public void spawnItems()
    {
        int spawnItem = Random.Range(0, Items.Length);
        Instantiate(Items[spawnItem], SpawnPoints[spawnIndex].position, Quaternion.identity);
        spawnIndex++;

    }
}
