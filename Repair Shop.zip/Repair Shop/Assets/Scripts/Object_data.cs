﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Object_data : MonoBehaviour
{

    /*
     * 
     * Assign Standard Condition Names and Price
     * 
     */

    //Item values

    float itemCost;
    float DeskPrice = 1275f;
    float ChestPrice = 650f;
    float ChairPrice = 300f;
    float DresserPrice = 750f;
    float DrumPrice = 300f;
    float SafePrice = 3000f;
    float TablePrice = 250f;

    float sellPrice;
    float DeskSell = 2250f;
    float ChestSell= 1000f;
    float ChairSell = 500f;
    float DresserSell = 1500f;
    float DrumSell = 560f;
    float SafeSell = 5000f;
    float TableSell = 500f;

    //Condition and Tool Data
    string firstConditionName = "Cond One";
    string secondConitionName = "Cond Two";
    string thirdConditionName = "Cond Three";
    string fourthConditionName = "Cond Four";
    string uniqueConditionName;


    //ItemRepairCost
    float conOneCost;
    float conTwoCost;
    float conThreeCost;
    float conFourCost;
    float conUniqueCost;
    

    //UI Variables

    Vector3 xVector = new Vector3(400, 0, 0);    
    Vector3 yVector = new Vector3(0, 80, 0);
    Button purchaseButton;
    Button conditionOneButton;
    Button conditionTwoButton;
    Button conditionThreeButton;
    Button conditionFourButton;
    Button conditionUniqueButton;
    Button conditionSellButton;



    GameObject econControl;
    GameObject temp_canvas;
    GameObject Repair_Canvas_Prefab;
    GameObject buy_ui;
    GameObject condition_ui_prefab;
    GameObject condition_ui;
    GameObject repair_canvas;

    float totalCash = 1000f;

    Transform parent;
    Camera zoomCam;

    int conditionValueOne;
    int conditionValueTwo;
    int conditionValueThree;
    int conditionValueFour;
    int conditionValueFive;

    int unknownChoiceOne;
    int unknownChoiceTwo;
    int unknownChoiceThree;






    void Start()
    {
      
        zoomCam = Camera.main;
        parent = GameObject.Find("ItemHolder").transform;
        this.transform.SetParent(parent, true);
        transform.name = transform.name.Replace("(Clone)", "");
        switch (transform.name)
        {

            /*
             * 
             * Update with item names and uniques
             * 
             * 
             */
            case "Desk":
                itemCost = DeskPrice;
                this.transform.rotation = Quaternion.Euler(0, 180, 0);
                //Set unique for Desk
                uniqueConditionName = "Desk Unique";

                sellPrice = DeskSell;
                //ItemRepairCost
                 conOneCost = 70f;
                 conTwoCost = 55f;
                 conThreeCost = 45f;
                 conFourCost = 95f;
                conUniqueCost = 300f;
                
                break;
            case "Chest":
                itemCost = ChestPrice;
                this.transform.rotation = Quaternion.Euler(-90, 180, 0);
                //Set unique for Cube
                uniqueConditionName = "Chest Unique";

                sellPrice = ChestSell;
                //ItemRepairCost
                 conOneCost = 30f;
                 conTwoCost = 25f;
                 conThreeCost = 20f;
                 conFourCost = 15f;
                conUniqueCost = 50f;
                break;
            case "Chair":
                itemCost = ChairPrice;
                this.transform.rotation = Quaternion.Euler(-90, 180, 0);

                //Set unique for Sphere
                uniqueConditionName = "Chair Unique";

                sellPrice = ChairSell;
                //ItemRepairCost
                conOneCost = 35f;
                conTwoCost = 10f;
                conThreeCost = 15f;
                conFourCost = 8f;
                conUniqueCost = 80f;
                
                break;
            case "Drum":
                itemCost = DrumPrice;
                this.transform.rotation = Quaternion.Euler(0, 180, 0);
                //Set unique for Cylinder
                uniqueConditionName = "Drum Unique";

                sellPrice = DrumSell;
                //ItemRepairCost
                 conOneCost = 25f;
                 conTwoCost = 10f;
                 conThreeCost = 35f;
                 conFourCost = 15f;
                conUniqueCost = 50f;
                break;
            case "Safe":
                itemCost = SafePrice;
                this.transform.rotation = Quaternion.Euler(-90, 180, 0);
                //Set unique for Capsule
                uniqueConditionName = "Safe Unique";

                sellPrice = SafeSell;
                //ItemRepairCost
                 conOneCost = 175f;
                 conTwoCost = 150f;
                 conThreeCost = 250f;
                 conFourCost = 175f;
                conUniqueCost = 400f;
                break;
            case "Table":
                itemCost = TablePrice;
                this.transform.rotation = Quaternion.Euler(-120, -0, -90);
                //Set unique for Capsule
                uniqueConditionName = "Table Unique";

                sellPrice = TableSell;
                //ItemRepairCost
                 conOneCost = 14f;
                 conTwoCost = 15f;
                 conThreeCost = 16f;
                 conFourCost = 15f;
                conUniqueCost = 50f;
                break;
            case "Dresser":
                itemCost = DresserPrice;
                this.transform.rotation = Quaternion.Euler(-90, 180, 0);
                //Set unique for Capsule
                uniqueConditionName = "Capsule Unique";

                
                //ItemRepairCost
                 conOneCost = 50f;
                 conTwoCost = 60f;
                 conThreeCost = 60f;
                 conFourCost = 75f;
                conUniqueCost = 125f;
                break;
            default:
                Debug.LogError("NO PRICE FOR ITEM SET!");
                break;                
        }


        //Grab UI prefab buttons and "allign" on screen


        temp_canvas = GameObject.Find("Button_Canvas");       
        

        GameObject Buy_Button_Prefab = Resources.Load("buy_button", typeof(GameObject)) as GameObject;
        Repair_Canvas_Prefab = Resources.Load("Repair_Canvas", typeof(GameObject)) as GameObject;
        condition_ui_prefab = Resources.Load("ConditionDisplay", typeof(GameObject)) as GameObject;

        buy_ui = Instantiate(Buy_Button_Prefab, this.transform.position * 40 + xVector + yVector, Buy_Button_Prefab.transform.rotation, temp_canvas.transform) as GameObject;
        buy_ui.transform.SetParent(temp_canvas.transform, false);
        buy_ui.transform.Find("Name").GetComponent<Text>().text = transform.name;
        buy_ui.transform.Find("Price").GetComponent<Text>().text = "$"+itemCost.ToString();
        purchaseButton = buy_ui.transform.GetComponent<Button>();
        purchaseButton.onClick.AddListener(ClickToBuy);

        //Assign Condition values and update the UI to display values
        conditionValueOne = returnCondition();
        conditionValueTwo = returnCondition();
        conditionValueThree = returnCondition();
        conditionValueFour = returnCondition();
        conditionValueFive = returnCondition();

        


        buy_ui.transform.GetChild(3).GetChild(0).GetComponent<Image>().fillAmount = conditionValueOne * 0.2f;
        buy_ui.transform.GetChild(4).GetChild(0).GetComponent<Image>().fillAmount = conditionValueTwo * 0.2f;
        buy_ui.transform.GetChild(5).GetChild(0).GetComponent<Image>().fillAmount = conditionValueThree * 0.2f;
        buy_ui.transform.GetChild(6).GetChild(0).GetComponent<Image>().fillAmount = conditionValueFour   * 0.2f;
        buy_ui.transform.GetChild(7).GetChild(0).GetComponent<Image>().fillAmount = conditionValueFive * 0.2f;

        buy_ui.transform.GetChild(3).GetChild(1).GetComponent<Text>().text = firstConditionName + conditionValueOne + "/5";
        buy_ui.transform.GetChild(4).GetChild(1).GetComponent<Text>().text = secondConitionName + conditionValueTwo + "/5";
        buy_ui.transform.GetChild(5).GetChild(1).GetComponent<Text>().text = thirdConditionName + conditionValueThree + "/5";
        buy_ui.transform.GetChild(6).GetChild(1).GetComponent<Text>().text = fourthConditionName + conditionValueFour + " /5";
        buy_ui.transform.GetChild(7).GetChild(1).GetComponent<Text>().text = uniqueConditionName + conditionValueFive + "/5";

        unknownChoiceOne = returnCondition();        
        unknownChoiceTwo = returnCondition();
        if(unknownChoiceOne == unknownChoiceTwo)
        {
            unknownChoiceThree = returnCondition();
            makeUnknown(unknownChoiceThree);
        }

        makeUnknown(unknownChoiceOne);
        makeUnknown(unknownChoiceTwo);
        
        

        //Econ and stuff
        econControl = GameObject.Find("EconController");
        



    }


    public int returnCondition()
    {
        int random_condition = Random.Range(0, 6);
        return random_condition;
    }
    public void ClickToBuy()
    {
        zoomCam.transform.GetComponent<Camera_Controller>().zoomToObject(this.transform);
        econControl.GetComponent<Player_Econ_Script>().itemBought(itemCost);
        this.transform.SetParent(null); 

        foreach(Transform child in temp_canvas.transform)
        {
            Destroy(child.gameObject);
        }       
        
        repair_canvas = Instantiate(Repair_Canvas_Prefab, Repair_Canvas_Prefab.transform.position, Repair_Canvas_Prefab.transform.rotation, Repair_Canvas_Prefab.transform) as GameObject;

        createConditonUI();


        Destroy(parent.gameObject);


    }


    // Update is called once per frame
    void Update()
    {

        totalCash = econControl.GetComponent<Player_Econ_Script>().checkTotalCash();

        //Enable Purchase
        if (totalCash < itemCost)
        {
            purchaseButton.interactable = false;
        }
        else
        {
            purchaseButton.interactable = true;
        }

        
        
        
        


        //Enabel Repairs

        if (condition_ui)
        {
            if (conditionValueOne != 5 && totalCash >= conOneCost)
            {
                conditionOneButton.interactable = true;
            }
            else
            {
                conditionOneButton.interactable = false;
            }

            if (conditionValueTwo != 5 && totalCash >= conTwoCost)
            {
                conditionTwoButton.interactable = true;
            }
            else
            {
                conditionTwoButton.interactable = false;
            }

            if (conditionValueThree != 5 && totalCash >= conThreeCost)
            {
                conditionThreeButton.interactable = true;
            }
            else
            {
                conditionThreeButton.interactable = false;
            }

            if (conditionValueFour != 5 && totalCash >= conFourCost)
            {
                conditionFourButton.interactable = true;
            }
            else
            {
                conditionFourButton.interactable = false;
            }

            if (conditionValueFive != 5 && totalCash >= conUniqueCost)
            {
                conditionUniqueButton.interactable = true;
            }
            else
            {
                conditionUniqueButton.interactable = false;
            }
        }
    }

    public void createConditonUI()
    {
        condition_ui = Instantiate(condition_ui_prefab, condition_ui_prefab.transform.position, condition_ui_prefab.transform.rotation, condition_ui_prefab.transform) as GameObject;
        condition_ui.transform.GetChild(0).GetChild(0).GetComponent<Image>().fillAmount = conditionValueOne * 0.2f;
        condition_ui.transform.GetChild(1).GetChild(0).GetComponent<Image>().fillAmount = conditionValueTwo * 0.2f;
        condition_ui.transform.GetChild(2).GetChild(0).GetComponent<Image>().fillAmount = conditionValueThree * 0.2f;
        condition_ui.transform.GetChild(3).GetChild(0).GetComponent<Image>().fillAmount = conditionValueFour * 0.2f;
        condition_ui.transform.GetChild(4).GetChild(0).GetComponent<Image>().fillAmount = conditionValueFive * 0.2f;

        condition_ui.transform.GetChild(0).GetChild(1).GetComponent<Text>().text = firstConditionName + conditionValueOne + "/5";
        condition_ui.transform.GetChild(1).GetChild(1).GetComponent<Text>().text = secondConitionName + conditionValueTwo + "/5";
        condition_ui.transform.GetChild(2).GetChild(1).GetComponent<Text>().text = thirdConditionName + conditionValueThree + "/5";
        condition_ui.transform.GetChild(3).GetChild(1).GetComponent<Text>().text = fourthConditionName + conditionValueFour + "/5";
        condition_ui.transform.GetChild(4).GetChild(1).GetComponent<Text>().text = uniqueConditionName + conditionValueFive + "/5";

        condition_ui.transform.SetParent(temp_canvas.transform, false);
        
        conditionOneButton = repair_canvas.transform.GetChild(1).transform.GetComponent<Button>();
        conditionTwoButton = repair_canvas.transform.GetChild(2).transform.GetComponent<Button>();
        conditionThreeButton = repair_canvas.transform.GetChild(3).transform.GetComponent<Button>();
        conditionFourButton = repair_canvas.transform.GetChild(4).transform.GetComponent<Button>();
        conditionUniqueButton = repair_canvas.transform.GetChild(5).transform.GetComponent<Button>();
        conditionSellButton = repair_canvas.transform.GetChild(6).transform.GetComponent<Button>();


        repair_canvas.transform.GetChild(1).GetChild(1).transform.GetComponent<Text>().text = "$" + conOneCost.ToString();
        repair_canvas.transform.GetChild(2).GetChild(1).transform.GetComponent<Text>().text = "$" + conTwoCost.ToString();
        repair_canvas.transform.GetChild(3).GetChild(1).transform.GetComponent<Text>().text = "$" + conThreeCost.ToString();
        repair_canvas.transform.GetChild(4).GetChild(1).transform.GetComponent<Text>().text = "$" + conFourCost.ToString();
        repair_canvas.transform.GetChild(5).GetChild(1).transform.GetComponent<Text>().text = "$" + conUniqueCost.ToString();

        conditionOneButton.onClick.AddListener(ClickConditionOne);
        conditionTwoButton.onClick.AddListener(ClickConditionTwo);
        conditionThreeButton.onClick.AddListener(ClickConditionThree);
        conditionFourButton.onClick.AddListener(ClickConditionFour);
        conditionUniqueButton.onClick.AddListener(ClickConditionUnique);
        conditionSellButton.onClick.AddListener(sellItem);
        
        

    }

    public void makeUnknown(int unkownChoice)
    {
        switch (unkownChoice)
        {
            case 0:
                buy_ui.transform.GetChild(3).GetChild(0).GetComponent<Image>().fillAmount = 1;
                buy_ui.transform.GetChild(3).GetChild(0).GetComponent<Image>().color = Color.grey;
                buy_ui.transform.GetChild(3).GetChild(1).GetComponent<Text>().text = "UNKNOWN";
                break;

            case 1:
                buy_ui.transform.GetChild(4).GetChild(0).GetComponent<Image>().fillAmount = 1;
                buy_ui.transform.GetChild(4).GetChild(0).GetComponent<Image>().color = Color.grey;
                buy_ui.transform.GetChild(4).GetChild(1).GetComponent<Text>().text = "UNKNOWN";
                break;
            case 2:
                buy_ui.transform.GetChild(5).GetChild(0).GetComponent<Image>().fillAmount = 1;
                buy_ui.transform.GetChild(5).GetChild(0).GetComponent<Image>().color = Color.grey;
                buy_ui.transform.GetChild(5).GetChild(1).GetComponent<Text>().text = "UNKNOWN";
                break;
            case 3:
                buy_ui.transform.GetChild(6).GetChild(0).GetComponent<Image>().fillAmount = 1;
                buy_ui.transform.GetChild(6).GetChild(0).GetComponent<Image>().color = Color.grey;
                buy_ui.transform.GetChild(6).GetChild(1).GetComponent<Text>().text = "UNKNOWN";
                break;
            case 4:
                buy_ui.transform.GetChild(7).GetChild(0).GetComponent<Image>().fillAmount = 1;
                buy_ui.transform.GetChild(7).GetChild(0).GetComponent<Image>().color = Color.grey;
                buy_ui.transform.GetChild(7).GetChild(1).GetComponent<Text>().text = "UNKNOWN";
                break;

            default: break;

        }
    }

    public void ClickConditionOne()
    {
        econControl.GetComponent<Player_Econ_Script>().itemBought(conOneCost);
        

        conditionValueOne++;
        condition_ui.transform.GetChild(0).GetChild(0).GetComponent<Image>().fillAmount = conditionValueOne * 0.2f;
        condition_ui.transform.GetChild(0).GetChild(1).GetComponent<Text>().text = firstConditionName + conditionValueOne + "/5";

    }

    public void ClickConditionTwo()
    {
        econControl.GetComponent<Player_Econ_Script>().itemBought(conTwoCost);
        conditionValueTwo++;
        condition_ui.transform.GetChild(1).GetChild(0).GetComponent<Image>().fillAmount = conditionValueTwo * 0.2f;
        condition_ui.transform.GetChild(1).GetChild(1).GetComponent<Text>().text = secondConitionName + conditionValueTwo + "/5";
    }

    public void ClickConditionThree()
    {
        econControl.GetComponent<Player_Econ_Script>().itemBought(conThreeCost);
        conditionValueThree++;
        condition_ui.transform.GetChild(2).GetChild(0).GetComponent<Image>().fillAmount = conditionValueThree * 0.2f;
        condition_ui.transform.GetChild(2).GetChild(1).GetComponent<Text>().text = thirdConditionName + conditionValueThree + "/5";
    }

    public void ClickConditionFour()
    {
        econControl.GetComponent<Player_Econ_Script>().itemBought(conFourCost);
        conditionValueFour++;
        condition_ui.transform.GetChild(3).GetChild(0).GetComponent<Image>().fillAmount = conditionValueFour * 0.2f;
        condition_ui.transform.GetChild(3).GetChild(1).GetComponent<Text>().text = fourthConditionName + conditionValueFour + "/5";
    }

    public void ClickConditionUnique()
    {
        econControl.GetComponent<Player_Econ_Script>().itemBought(conUniqueCost);
        conditionValueFive++;
        condition_ui.transform.GetChild(4).GetChild(0).GetComponent<Image>().fillAmount = conditionValueFive * 0.2f;
        condition_ui.transform.GetChild(4).GetChild(1).GetComponent<Text>().text = uniqueConditionName + conditionValueFive + "/5";
    }

    public void sellItem()
    {

        switch (transform.name)
        {
            case "Desk":
                itemCost = DeskPrice;
                this.transform.rotation = Quaternion.Euler(0, 180, 0);
                //Set unique for Desk
                uniqueConditionName = "Desk Unique";

                sellPrice = DeskSell;
                //ItemRepairCost
                conOneCost = 70f;
                conTwoCost = 55f;
                conThreeCost = 45f;
                conFourCost = 95f;
                conUniqueCost = 300f;

                break;
            case "Chest":
                itemCost = ChestPrice;
                this.transform.rotation = Quaternion.Euler(-90, 180, 0);
                //Set unique for Cube
                uniqueConditionName = "Chest Unique";

                sellPrice = ChestSell;
                //ItemRepairCost
                conOneCost = 30f;
                conTwoCost = 25f;
                conThreeCost = 20f;
                conFourCost = 15f;
                conUniqueCost = 50f;
                break;
            case "Chair":
                itemCost = ChairPrice;
                this.transform.rotation = Quaternion.Euler(-90, 180, 0);

                //Set unique for Sphere
                uniqueConditionName = "Chair Unique";

                sellPrice = ChairSell;
                //ItemRepairCost
                conOneCost = 35f;
                conTwoCost = 10f;
                conThreeCost = 15f;
                conFourCost = 8f;
                conUniqueCost = 80f;

                break;
            case "Drum":                

                sellPrice = DrumSell;                
                break;
            case "Safe":
                
                sellPrice = SafeSell;
                
                break;
            case "Table":
                

                sellPrice = TableSell;
                
                break;
            case "Dresser":
                sellPrice = DresserSell;

                break;
            default:
                Debug.LogError("Error selling");
                break;
        }



        float _sellValue = calcPrice(sellPrice);
        econControl.GetComponent<Player_Econ_Script>().sellItem(_sellValue);
    }


    public float calcPrice(float sellPrice)
    {
        float percent = (conditionValueOne + conditionValueTwo + conditionValueThree + conditionValueFour + conditionValueFive) * 4;
        float valueFull = sellPrice / 100;
        float sellValue = valueFull * percent;
       
        return sellValue;
    }
}
