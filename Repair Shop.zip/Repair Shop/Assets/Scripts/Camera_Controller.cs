﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class Camera_Controller : MonoBehaviour
{
    public float smoothSpeed = 0.2f ;
    public Vector3 offset;
    Transform zoomTarget;

    public void zoomToObject(Transform targetObject)
    {
        zoomTarget = targetObject;
        transform.position = zoomTarget.position + offset;
    }

}
