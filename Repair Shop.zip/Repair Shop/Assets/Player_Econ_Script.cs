﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Player_Econ_Script : MonoBehaviour
{
    public Text playerMoneyText;
    public float playerCash;
    public float sellValue;

    private void Awake()
    {
        DontDestroyOnLoad(this);
    }

    void Start()
    {
        playerCash = 2000f;        
    }

    public float checkTotalCash()
    {
        return playerCash;
    }

    public void itemBought(float price)
    {
        playerCash -= price;        
    }
    // Update is called once per frame
    void Update()
    {
        playerMoneyText.text = "Cash: $" + playerCash;

    }

    public void sellItem(float sellPrice)
    {
        
        itemBought(sellPrice * -1);
        reloadScene();
    

    }

    public void reloadScene()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    public void startGame()
    {
        SceneManager.LoadScene("Workshop");
    }

}



